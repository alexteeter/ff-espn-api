##properties
year = 0 ##year goes here
league = 0 ##leagueID goes here
debug = ''